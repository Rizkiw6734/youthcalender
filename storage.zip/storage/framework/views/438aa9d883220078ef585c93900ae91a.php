<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Tambah Bulan</h3>

    <form action="<?php echo e(route('bulan.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Nama Bulan</label>
            <input type="text" name="nama_bulan" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Gambar</label>
            <input type="file" name="gambar" class="form-control">
        </div>

        <button class="btn btn-primary">Simpan</button>
        <a href="<?php echo e(route('bulan.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\youthkalender\youthkalender\resources\views/bulan/create.blade.php ENDPATH**/ ?>