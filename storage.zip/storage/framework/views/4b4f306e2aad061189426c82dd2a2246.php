<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Edit Bulan</h3>

    <form action="<?php echo e(route('bulan.update', $bulan->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Nama Bulan</label>
            <input type="text" name="nama_bulan" value="<?php echo e($bulan->nama_bulan); ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Gambar</label><br>
            <?php if($bulan->gambar): ?>
                <img src="<?php echo e(asset('storage/' . $bulan->gambar)); ?>" width="120" class="mb-2">
            <?php endif; ?>
            <input type="file" name="gambar" class="form-control">
        </div>

        <button class="btn btn-primary">Perbarui</button>
        <a href="<?php echo e(route('bulan.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\youthkalender\youthkalender\resources\views/bulan/edit.blade.php ENDPATH**/ ?>