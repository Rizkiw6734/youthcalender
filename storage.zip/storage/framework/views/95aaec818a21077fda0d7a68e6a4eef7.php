<?php $__env->startSection('content'); ?>
<div class="container">

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="d-flex justify-content-between mb-3">
        <h3>Daftar Bulan</h3>
        <a href="<?php echo e(route('bulan.create')); ?>" class="btn btn-primary">+ Tambah Bulan</a>
    </div>

    <div class="row">
        <?php $__currentLoopData = $bulans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card mb-3">
                <?php if($bulan->gambar): ?>
                    <img src="<?php echo e(asset('storage/' . $bulan->gambar)); ?>" class="card-img-top" height="150">
                <?php endif; ?>
                <div class="card-body text-center">
                    <h5><?php echo e($bulan->nama_bulan); ?></h5>

                    <a href="<?php echo e(route('bulan.edit', $bulan->id)); ?>" class="btn btn-warning btn-sm">Edit</a>

                    <form action="<?php echo e(route('bulan.destroy', $bulan->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm" onclick="return confirm('Hapus bulan ini?')">
                            Hapus
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\youthkalender\youthkalender\resources\views/bulan/index.blade.php ENDPATH**/ ?>